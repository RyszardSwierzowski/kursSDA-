package wyjatki;

public class NotFoundItem extends Exception/*RuntimeException*/
{

}
