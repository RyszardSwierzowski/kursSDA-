
import generyki.generyki2.Pair;

import static stringi.Strinngi.*;

public class Main {




        public static void main(String[] args)

        {




            /*--------------------- Enum
                BookStatus status = BookStatus.BORROW;


             */

            /*--------------------- Object



             */



            /* -------------              STRINGI

            //wypiszOdADoZCoDrugi();
            //wypiszOdZDoA();
            //najwieksza("alfabet");
            //podmien(tekst);
            //suma("72");
            //mirror("AntyEcho");
            //zliczWystapienia("aZZ 1 9 !!!");
            //trzyPierwsze("a");
            //System.out.println(trzyPierwsze(" b c "));
            //System.out.println(czteryOstatnie("dsadasd dsad s "));System.out.println(czteryOstatnie(" a"));
            */
        }
}
