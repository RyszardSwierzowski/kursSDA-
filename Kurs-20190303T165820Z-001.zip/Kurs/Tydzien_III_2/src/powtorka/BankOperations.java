package powtorka;

public interface BankOperations {
     double computerCommistion();
     void incresseAmount(double val);
     void decreaseAmount(double val);
}
