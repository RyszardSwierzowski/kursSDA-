package powtorka.powtorka_tydzien_IV_1;

public interface Nauka
{
    void czytaj(String nazwaKsiazki);

}
