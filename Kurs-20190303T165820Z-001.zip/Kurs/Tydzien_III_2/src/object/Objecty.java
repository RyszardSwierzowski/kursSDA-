package object;

public class Objecty {
}
