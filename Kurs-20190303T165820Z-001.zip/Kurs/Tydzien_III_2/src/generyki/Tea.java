package generyki;

public class Tea extends Drink {
}
