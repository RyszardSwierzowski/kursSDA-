package generyki;

public class Cups {

    public static void main(String... s){
        Mug kubek = new Mug();
        Mug kubek2 = new Mug();
        kubek.add(new Coffee());
       // kubek2.add(new Tea());
    }

}
