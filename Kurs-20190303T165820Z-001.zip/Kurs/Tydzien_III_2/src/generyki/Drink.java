package generyki;

public class Drink {

}
