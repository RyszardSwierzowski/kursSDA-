package generyki;

public class Mug extends GenericCup<Coffee> {
    @Override
    void add(Coffee drink) {

    }
}
