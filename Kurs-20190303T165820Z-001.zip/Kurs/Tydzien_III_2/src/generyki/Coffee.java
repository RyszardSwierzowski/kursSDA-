package generyki;

public class Coffee extends Drink {

}
