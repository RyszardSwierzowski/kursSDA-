import figury.*;

public class Main {

    public static void main(String[] args)
    {
//        System.out.println(new Varargs().concat(1,"Kot","Makaron"));
//        System.out.println(new Varargs().concat(1,"Kot","Makaron","eqwe","saasa","sasa"));
//        System.out.println(new Varargs().concat(1,"Kot"));
//        System.out.println(new Varargs().concat2(2,"Kot","Makaron","kisiel"));


    }
}
