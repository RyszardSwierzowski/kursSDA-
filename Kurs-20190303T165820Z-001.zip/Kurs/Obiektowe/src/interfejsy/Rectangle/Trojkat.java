package interfejsy.Rectangle;

public class Trojkat /*extends Figura*/ {
    private double a,b,c;

//    public Trojkat(int a, int b, int c) {
//
//        if( (a>=b && b>=c)|| (b>=a && a>=c)|| )
//        this.a = a;
//        this.b = b;
//        this.c = c;
//
//
//     }
//
//
//
//    @Override
//    double getArea() {
//        if(a==b&& a==c && c==b){
//            return (a*Math.sqrt(3))/4;
//        }else  if(((a==b)&& a!=c)||(a==c)&& c!=b){
//            return 0;
//        }else {
//            return 0;
//        }
//    }
//
//    @Override
//    double getPermiter() {
//        return a+b+c;
//    }


}
