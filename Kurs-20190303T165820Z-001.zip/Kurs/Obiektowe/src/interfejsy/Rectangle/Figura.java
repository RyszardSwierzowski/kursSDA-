package interfejsy.Rectangle;

public abstract class  Figura {


    abstract  double getArea();
    abstract  double getPermiter();
}
