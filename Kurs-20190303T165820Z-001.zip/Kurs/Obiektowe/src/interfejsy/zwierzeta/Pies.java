package interfejsy.zwierzeta;

public class Pies implements TresowanyZwierzak {
    @Override
    public String dajGlos() {
        return "Hau hau";
    }
}
