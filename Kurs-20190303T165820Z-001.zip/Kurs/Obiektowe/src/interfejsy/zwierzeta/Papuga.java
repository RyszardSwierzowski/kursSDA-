package interfejsy.zwierzeta;

public class Papuga implements TresowanyZwierzak {
    @Override
    public String dajGlos() {
        return "Miała matka syna ...";
    }
}
