package interfejsy.zwierzeta;

public class Kot implements TresowanyZwierzak {
    @Override
    public String dajGlos() {
        return "Miau miau";
    }
}
