package interfejsy.zwierzeta;

public class Rybka implements TresowanyZwierzak {
    @Override
    public String dajGlos() {
        return "bul bul";
    }
}
