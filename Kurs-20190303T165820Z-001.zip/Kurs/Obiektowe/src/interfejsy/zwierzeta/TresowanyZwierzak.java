package interfejsy.zwierzeta;

public interface TresowanyZwierzak {
    String dajGlos();
}
