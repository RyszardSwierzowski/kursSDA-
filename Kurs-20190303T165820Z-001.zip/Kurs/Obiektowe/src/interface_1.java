interface interface_1 {
    public String concat(int x , String... args);
    public String concat2(int x , String... args);

}