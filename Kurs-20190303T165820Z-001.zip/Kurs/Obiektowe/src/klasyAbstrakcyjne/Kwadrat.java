package klasyAbstrakcyjne;

public class Kwadrat extends Prostokat {
//    int bok;
    public Kwadrat(int bok) {
        super(bok, bok);
    }

    public int obliczPole(){
        return super.obliczPole();
    }
}
